<?php 
   

      // $name = 'name';
      // $age = 23;
      
      // echo "My name is $name. I am $age years old";

      // echo "<br>";

      
      // $name = "Hasan";
   
      // echo 'Miami ' . $name . "\n";

      // $name = "Habib";

      // echo 'welcome ' . $name;

      
      // $my_name = 1; 

      // $myName = 'Habib';

      // $MyName = 'Habib';


      // define('PI', 3.14);

      // const DB_NAME = 'test';

      // echo DB_NAME;


      // $name = 'Hasan';

      // $1name = 'hasan';

      // $name = 'Habib';

      // $my name = 'Habib';

      // $echo = 'Habib';

      // $my1name = 'Hasan';

      // $name = 'Hasan';
      // $age = 20;

      // echo "my name is ' . $name . '. I\'m' . $age . ' years old .";

      // printf('My name is %s. I\'m %d years old. ', $name, $age);

      // $result = sprintf('My name is %s. I\'m %d years old. ', $name, $age);

      // echo $result;

      // $arr = [1,2,3,4,5];
      
      // print_r($arr);

      // $name = 'Hasan';

      // $age = 20.2232;

      // $is_verified = true;

      // var_dump($name, $age, $is_verified);

      // $date = 'h1';

      // echo $date;

      // $students = [
      //    'name' => 'Hasan',
      //    'age' => 20,
      //    'is_verified' => true          
      // ];

      // var_dump($students['name']);   

      // $name = Null;

      // $filename = 'test.txt';

      // $file = fopen($filename, 'w');

      // if($file){
      //    $content = "Hello World";
      //    fwrite($file, $content);
      //    fclose($file);
      // }


      // Arithmetic Operators

      // $num1 = 10; 
      // $num2 = 20;

      // echo $num1 % $num2;
      
      // $num1 = 10; 
      // $num2 = 20;

      // $num1 %= $num2;

      // echo $num2;

      // $name = 10;
      // $num2 = '10';

      // var_dump($name != $num2);
      
      // $num1 = 10; 
      // $num2 = 11;

      // var_dump($num1 <=> $num2);

      // $num1 = 10;
       
      // echo ++$num1;

      

